# Example Unix Project

- `data/`
- `results/`
  - `figures/`
  - `filtered_data/`
- `scripts/`